package com.example.linqi.mf_denoisy;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
/*
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
*/
import android.content.Context;
import android.graphics.SurfaceTexture;

import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLExt;
import android.opengl.EGLSurface;
import android.opengl.GLSurfaceView;
import android.opengl.EGL14;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.util.Log;
import android.view.Surface;

public class  GLCameraRenderThread extends Thread {

    /*Filter Type Const*/
    public static final int FILTER_NONE = 0;
    public static final int FILTER_GREY = 1;
    public static final int FILTER_SEPIA_TONE = 2;
    public static final int FILTER_NEGATIVE_COLOR = 3;
    public static final int FILTER_VIGNETTE = 4;
    public static final int FILTER_FISHEYE = 5;
    public static final int FILTER_CYAN = 6;
    public static final int FILTER_RADIAL_BLUR = 7;
    public static final int FILTER_H_MIRROR = 8;
    public static final int FILTER_V_MIRROR = 9;
    public static final int FILTER_MF_DENOISY = 10;

    private static float shapeCoords[] = {
            -1.0f, 1.0f, 0.0f,   // top left
            -1.0f, -1.0f, 0.0f,   // bottom left
            1.0f, -1.0f, 0.0f,   // bottom right
            1.0f, 1.0f, 0.0f}; // top right

    private static float shapeCoordsFishEye[] = {
            -1.0f, 0.5625f, 0.0f,   // top left
            -1.0f, -0.5625f, 0.0f,   // bottom left
            1.0f, -0.5625f, 0.0f,   // bottom right
            1.0f, 0.5625f, 0.0f}; // top right


    //90 degree rotated
    private static float textureCoords[] = {
            0.0f, 1.0f,   // top left
            1.0f, 1.0f,   // bottom left
            1.0f, 0.0f,    // bottom right
            0.0f, 0.0f}; // top right

    //90 degree rotated
    private static float textureCoords0[] = {
            0.0f, 0.0f,   // bottom left
            0.0f, 1.0f,   // top left
            1.0f, 1.0f, // top right
            1.0f, 0.0f};   // bottom right


    private static short drawOrder[] = {0, 1, 2, 0, 2, 3};

    private static final int COORDS_PER_VERTEX = 3;
    private static final int TEXTURE_COORS_PER_VERTEX = 2;

    /*Draw region*/
    int mWidth;
    int mHeight;

    //XXX To fix a strange bug, which I cannot find the root cause.
    //When zoom out/in the filter, there's always an unpleasant flash after zoom
    //So I defer the size change for one frame.
    int mDeferWidth;
    int mDeferHeight;

    private int mProgram;
    private int mProgramFBO;
    private int mTexName = 0;
    private SurfaceTexture mSurface;

    private boolean mSuspend = false;
    private boolean mCameraPreview = true;
    private int[] mTexList = new int[6];
    private int mTexGroup[] = {GLES20.GL_TEXTURE0, GLES20.GL_TEXTURE1,
            GLES20.GL_TEXTURE2, GLES20.GL_TEXTURE3, GLES20.GL_TEXTURE4, GLES20.GL_TEXTURE5 };

    /*For EGL Setup*/
    /*
    private EGL10 mEgl;
    private EGLDisplay mEglDisplay;
    private EGLConfig mEglConfig;
    private EGLContext mEglContext;
    private EGLSurface mEglSurface;
    */

    /*Vertex buffers*/
    private FloatBuffer mVertexBuffer;
    private FloatBuffer mTexCoordBuffer;
    private ShortBuffer mDrawListBuffer;

    private final int mFilter;
    public void suspendCameraPreview() {
        mCameraPreview = false;
    }
    public void resumeCameraPreview() {
        mCameraPreview = true;
    }

    public void suspendRendering() {
        mSuspend = true;
    }

    public void resumeRendering() {
        mSuspend = false;
    }

    public GLCameraRenderThread(SurfaceTexture surface, int filter) {
        mSurface = surface;
        mFilter = filter;
    }

    private static String readRawTextFile(Context context, int resId) {
        InputStream inputStream = context.getResources().openRawResource(resId);

        InputStreamReader inputreader = new InputStreamReader(inputStream);
        BufferedReader buffreader = new BufferedReader(inputreader);
        String line;
        StringBuilder text = new StringBuilder();

        try {
            while ((line = buffreader.readLine()) != null) {
                text.append(line);
                text.append('\n');
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return text.toString();
    }

    private int compileShader(final int type) {
        int program;
        GLPreviewActivity app = GLPreviewActivity.getAppInstance();

        int vertexShader = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER);
        int fragmentShader = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER);

        String vertexShaderCode;
        if(type == FILTER_MF_DENOISY)
            vertexShaderCode = readRawTextFile(app, R.raw.vertex_perspective);
        else
            vertexShaderCode = readRawTextFile(app, R.raw.vertex);

        String fragmentShaderCode;

        //switch(mFilter){
        switch (type) {
            case FILTER_GREY:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_grey_scale);
                break;
            case FILTER_SEPIA_TONE:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_sepia_tone);
                break;
            case FILTER_NEGATIVE_COLOR:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_negative_color);
                break;
            case FILTER_FISHEYE:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_fish_eye);
                break;
            case FILTER_CYAN:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_no_effect);
                break;
            case FILTER_RADIAL_BLUR:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_radial_blur);
                break;
            case FILTER_H_MIRROR:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_h_mirror);
                break;
            case FILTER_V_MIRROR:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_v_mirror);
                break;
            case FILTER_MF_DENOISY:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_add_frame);
                break;
            default:
                fragmentShaderCode = readRawTextFile(app, R.raw.fragment_no_effect);
                break;
        }

        GLES20.glShaderSource(vertexShader, vertexShaderCode);
        GLES20.glShaderSource(fragmentShader, fragmentShaderCode);

        int[] compileStatus = new int[1];
        GLES20.glCompileShader(vertexShader);

        GLES20.glGetShaderiv(vertexShader, GLES20.GL_COMPILE_STATUS, compileStatus, 0);
        if (compileStatus[0] == 0) {
            String err = GLES20.glGetShaderInfoLog(vertexShader);
            throw new RuntimeException("vertex shader compile failed:" + err);
        }
        GLES20.glCompileShader(fragmentShader);
        GLES20.glGetShaderiv(fragmentShader, GLES20.GL_COMPILE_STATUS, compileStatus, 0);
        if (compileStatus[0] == 0) {
            String err = GLES20.glGetShaderInfoLog(fragmentShader);
            throw new RuntimeException("fragment shader compile failed:" + err);
        }

        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);

        return program;
    }

    public void prepareBuffer() {

		/*Vertex buffer*/
        ByteBuffer bb = ByteBuffer.allocateDirect(4 * shapeCoords.length);
        bb.order(ByteOrder.nativeOrder());

        mVertexBuffer = bb.asFloatBuffer();
		/*
		if (FILTER_FISHEYE == mFilter){
			mVertexBuffer.put(shapeCoordsFishEye);
		}
		else {
		*/
        mVertexBuffer.put(shapeCoords);
        //}
        mVertexBuffer.position(0);
		
		/*Vertex texture coord buffer*/
        ByteBuffer txeb = ByteBuffer.allocateDirect(4 * textureCoords.length);
        txeb.order(ByteOrder.nativeOrder());

        mTexCoordBuffer = txeb.asFloatBuffer();
        mTexCoordBuffer.put(textureCoords0);
        mTexCoordBuffer.position(0);
		
		/*Draw list buffer*/
        ByteBuffer dlb = ByteBuffer.allocateDirect(drawOrder.length * 2);
        dlb.order(ByteOrder.nativeOrder());

        mDrawListBuffer = dlb.asShortBuffer();
        mDrawListBuffer.put(drawOrder);
        mDrawListBuffer.position(0);
    }

    public void prepareHomography(float homography[],FloatBuffer HomographyBuffer) {

        ByteBuffer bb = ByteBuffer.allocateDirect(4 * homography.length);
        bb.order(ByteOrder.nativeOrder());
        HomographyBuffer = bb.asFloatBuffer();
        HomographyBuffer.put(homography);
        HomographyBuffer.position(0);

    }

    private int mTextures[] = new int[6];
    private void startPreview() {
        //int textures[] = new int[6];
        //设置一次性生成n个纹理，所生成的纹理代号放入textures中，
        //offset指定从第几个数组元素开始存放纹理代码
/*        GLES20.glGenTextures(6, mTextures, 0);
        GLPreviewActivity app = GLPreviewActivity.getAppInstance();
        app.startCamera(mTextures);
        mTexName = mTextures[0];*/
        GLES20.glGenTextures(6, mTexList, 0);
        GLPreviewActivity app = GLPreviewActivity.getAppInstance();
        app.startCamera(mTexList[0]);
    }

    private void updatePreview() {
        GLPreviewActivity app = GLPreviewActivity.getAppInstance();
        app.updateCamPreview();
    }

    public void drawFrame(final boolean CameraPreview) {
        if(!CameraPreview) {
            GLES20.glUseProgram(mProgramFBO);
            int positionHandler = GLES20.glGetAttribLocation(mProgramFBO, "aPosition");
            int texCoordHandler = GLES20.glGetAttribLocation(mProgramFBO, "aTextureCoord");

            int vHomograyHandle1 = GLES20.glGetUniformLocation(mProgramFBO, "uMVPMatrix1");
            int vHomograyHandle2 = GLES20.glGetUniformLocation(mProgramFBO, "uMVPMatrix2");
            int vHomograyHandle3 = GLES20.glGetUniformLocation(mProgramFBO, "uMVPMatrix3");
            int vHomograyHandle4 = GLES20.glGetUniformLocation(mProgramFBO, "uMVPMatrix4");
            int vHomograyHandle5 = GLES20.glGetUniformLocation(mProgramFBO, "uMVPMatrix5");
            int vHomograyHandle6 = GLES20.glGetUniformLocation(mProgramFBO, "uMVPMatrix6");
            float Homography[] = {1.0f,0.0f,0.0f,0.0f,1.0f,0.0f,0.0f,0.0f,1.0f};
            //FloatBuffer HomographyBuffer = new FloatBuffer;
            //prepareHomography(Homography,HomographyBuffer);
            GLES20.glUniformMatrix3fv(vHomograyHandle1, 1, false, Homography,0);
            GLES20.glUniformMatrix3fv(vHomograyHandle2, 1, false, Homography,0);
            GLES20.glUniformMatrix3fv(vHomograyHandle3, 1, false, Homography,0);
            GLES20.glUniformMatrix3fv(vHomograyHandle4, 1, false, Homography,0);
            GLES20.glUniformMatrix3fv(vHomograyHandle5, 1, false, Homography,0);
            GLES20.glUniformMatrix3fv(vHomograyHandle6, 1, false, Homography,0);
            int vSizeHandle = GLES20.glGetUniformLocation(mProgramFBO, "textureSize");
            float gSize[] = {mWidth,mHeight};
            GLES20.glUniform2fv(vSizeHandle, 1, gSize, 0);
            // Set the sampler texture unit index

            //GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            //GLES20.glEnable(GLES20.GL_BLEND);
            int textureHandler1 = GLES20.glGetUniformLocation(mProgramFBO, "u_samplerTexture1");
            int textureHandler2 = GLES20.glGetUniformLocation(mProgramFBO, "u_samplerTexture2");
            //int textureHandler3 = GLES20.glGetUniformLocation(mProgramFBO, "u_samplerTexture3");
            //int textureHandler4 = GLES20.glGetUniformLocation(mProgramFBO, "u_samplerTexture4");
            //int textureHandler5 = GLES20.glGetUniformLocation(mProgramFBO, "u_samplerTexture5");
            //int textureHandler6 = GLES20.glGetUniformLocation(mProgramFBO, "u_samplerTexture6");

            GLES20.glActiveTexture(mTexGroup[mCurrentTex]);
            //GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[mCurrentTex]);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[0]);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[1]);
            //GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[2]);
            //GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[3]);
            //GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[4]);
            //GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[5]);

            GLES20.glUniform1i(textureHandler1, 0);
            GLES20.glUniform1i(textureHandler2, 1);
            //GLES20.glUniform1i(textureHandler3, 2);
            //GLES20.glUniform1i(textureHandler4, 3);
            //GLES20.glUniform1i(textureHandler5, 4);
            //GLES20.glUniform1i(textureHandler6, 5);

            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

            GLES20.glEnableVertexAttribArray(positionHandler);

            GLES20.glVertexAttribPointer(positionHandler, COORDS_PER_VERTEX,
                    GLES20.GL_FLOAT, false,
                    COORDS_PER_VERTEX * 4, mVertexBuffer);

            GLES20.glEnableVertexAttribArray(texCoordHandler);
            GLES20.glVertexAttribPointer(texCoordHandler, TEXTURE_COORS_PER_VERTEX,
                    GLES20.GL_FLOAT, false,
                    TEXTURE_COORS_PER_VERTEX * 4, mTexCoordBuffer);

            GLES20.glDrawElements(GLES20.GL_TRIANGLES, drawOrder.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);
            //GLES20.glDisable(GLES20.GL_BLEND);

            GLES20.glDisableVertexAttribArray(positionHandler);
            GLES20.glDisableVertexAttribArray(texCoordHandler);
        }
        else {
            GLES20.glUseProgram(mProgram);

            int positionHandler = GLES20.glGetAttribLocation(mProgram, "aPosition");
            int texCoordHandler = GLES20.glGetAttribLocation(mProgram, "aTextureCoord");
            int textureHandler = GLES20.glGetUniformLocation(mProgram, "sTexture");

            //GLES20.glDisable(GLES20.GL_DEPTH_TEST);
            //GLES20.glEnable(GLES20.GL_BLEND);
            GLES20.glActiveTexture(mTexGroup[mCurrentTex]);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mTexList[mCurrentTex]);
            GLES20.glUniform1i(textureHandler, mCurrentTex);

            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);

            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

            GLES20.glEnableVertexAttribArray(positionHandler);

            GLES20.glVertexAttribPointer(positionHandler, COORDS_PER_VERTEX,
                    GLES20.GL_FLOAT, false,
                    COORDS_PER_VERTEX * 4, mVertexBuffer);

            GLES20.glEnableVertexAttribArray(texCoordHandler);
            GLES20.glVertexAttribPointer(texCoordHandler, TEXTURE_COORS_PER_VERTEX,
                    GLES20.GL_FLOAT, false,
                    TEXTURE_COORS_PER_VERTEX * 4, mTexCoordBuffer);

            GLES20.glDrawElements(GLES20.GL_TRIANGLES, drawOrder.length, GLES20.GL_UNSIGNED_SHORT, mDrawListBuffer);
            //GLES20.glDisable(GLES20.GL_BLEND);

            GLES20.glDisableVertexAttribArray(positionHandler);
            GLES20.glDisableVertexAttribArray(texCoordHandler);
        }
    }


    private android.opengl.EGLDisplay mEGLDisplay = EGL14.EGL_NO_DISPLAY;
    private EGLContext mEGLContext = EGL14.EGL_NO_CONTEXT;
    private EGLSurface mEGLSurface = EGL14.EGL_NO_SURFACE;
    private EGLSurface mEGLRecordSurface = EGL14.EGL_NO_SURFACE;
    private static final int EGL_RECORDABLE_ANDROID = 0x3142;

    //private Surface mSurface;
    private EGLConfig[] configs;
    private int[] version, configsAttribs = {
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
    }, numConfigs, contextAttribs = {
            EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            EGL14.EGL_NONE
    }, surfaceAttribs = {
            EGL14.EGL_NONE
    };

    EGLDisplay mScreenEglDisplay;
    EGLSurface mScreenEglDrawSurface;
    EGLSurface mScreenEglReadSurface;
    EGLContext mScreenEglContext;

    private void initGL(){
        mEGLDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
        if (mEGLDisplay == EGL14.EGL_NO_DISPLAY) {
            throw new RuntimeException("unable to get EGL14 display");
        }
        version = new int[2];
        if (!EGL14.eglInitialize(mEGLDisplay, version, 0, version, 1)) {
            throw new RuntimeException("unable to initialize EGL14");
        }

        //*
        // Configure EGL for recording and OpenGL ES 2.0.
        configs = new EGLConfig[1];
        numConfigs = new int[1];

        EGL14.eglChooseConfig(mEGLDisplay, configsAttribs, 0, configs, 0, configs.length,
                numConfigs, 0);

        mScreenEglDisplay = EGL14.eglGetCurrentDisplay();
        mScreenEglDrawSurface = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW);
        mScreenEglReadSurface = EGL14.eglGetCurrentSurface(EGL14.EGL_READ);
        mScreenEglContext = EGL14.eglGetCurrentContext();

        mEGLContext = EGL14.eglCreateContext(mEGLDisplay, configs[0], mScreenEglContext,
                contextAttribs, 0);
        mEGLSurface = EGL14.eglCreateWindowSurface(mEGLDisplay, configs[0], mSurface,
                surfaceAttribs, 0);

        boolean ret = EGL14.eglSurfaceAttrib(mEGLDisplay,mEGLSurface,EGL14.EGL_SWAP_BEHAVIOR,EGL14.EGL_BUFFER_PRESERVED);

        EGL14.eglMakeCurrent(mEGLDisplay, mEGLSurface, mEGLSurface, mEGLContext);

    }
    int mCurrentTex = 0;
	boolean isFirst = true;
	@Override
	public synchronized void run(){
		GLPreviewActivity app = GLPreviewActivity.getAppInstance();
		
		initGL();
		mProgram = compileShader(FILTER_CYAN);
        mProgramFBO = compileShader(FILTER_MF_DENOISY);
        //mProgram = compileShader(FILTER_FISHEYE);
		prepareBuffer();
		startPreview();

		while(true){
			
			if (false == mSuspend) {
				synchronized(app){

                    app.attachCameraTexture(mTexList[mCurrentTex]);

					app.updateCamPreview();
					GLES20.glViewport(0, 0, mWidth, mHeight);
					if (mDeferWidth != 0){
						mWidth = mDeferWidth;
						mHeight = mDeferHeight;
						mDeferWidth = 0;
					}

                    if (isFirst) {
                        GLES20.glClearColor(1.0f, 0.0f, 0.0f, 1.0f);
                        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
                        isFirst = false;
                    }

					drawFrame(mCameraPreview);
                    //The OpenGL ES texture object will be deleted as a result of this call
					app.detachCAmeraTexture();
				}
				
				if (!EGL14.eglSwapBuffers(mEGLDisplay, mEGLSurface)/*mEgl.eglSwapBuffers(mEglDisplay, mEglSurface)*/){
					throw new RuntimeException("Cannot swap buffers");
				}
                mCurrentTex++;
                if (mCurrentTex == 5)
                    mCurrentTex = 0;
			}
		
			try{
				wait();
			}
			catch (Exception e){
				break;
			}
			
		}
	}
	
	synchronized public void setRegion(int width, int height){
		if (mWidth != 0){
			mDeferWidth = width;
			mDeferHeight = height;
		}
		else {
			mWidth = width;
			mHeight = height;
			mDeferWidth = 0;
		}
	}
}
