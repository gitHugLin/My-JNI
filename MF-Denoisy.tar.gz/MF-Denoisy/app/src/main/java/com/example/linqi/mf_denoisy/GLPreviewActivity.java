package com.example.linqi.mf_denoisy;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.ImageButton;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.SurfaceTexture;
import android.graphics.SurfaceTexture.OnFrameAvailableListener;
import android.hardware.Camera;
import android.hardware.Camera.Size;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.ViewTreeObserver.OnDrawListener;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.view.MotionEvent;
import android.util.Log;
import android.view.View.OnClickListener;

public class GLPreviewActivity extends Activity implements OnFrameAvailableListener, Camera.PreviewCallback{

	@Override
	public void onPreviewFrame(byte[] data, Camera camera) {

	}

	class TextureCallback implements TextureView.SurfaceTextureListener {
		private int mIndex;
		private int mFilter;
		
		TextureCallback(int index, int filter){
			mIndex = index;
			mFilter = filter;
		}

		@Override
		public void onSurfaceTextureAvailable(SurfaceTexture surface,
				int width, int height) {
			mRenderThread[mIndex] = new GLCameraRenderThread(surface, mFilter);
			mRenderThread[mIndex].setRegion( width , height );
			mRenderThread[mIndex].start();
		}

		@Override
		public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void onSurfaceTextureSizeChanged(SurfaceTexture surface,
				int width, int height) {
			// TODO Auto-generated method stub
			mRenderThread[mIndex].setRegion(width, height);
		}

		@Override
		public void onSurfaceTextureUpdated(SurfaceTexture surface) {
			// TODO Auto-generated method stub
			
		}
		
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_UP){
			mCamera.autoFocus(null);
		}
		//else if (event.getAction() == MotionEvent.ACTION_DOWN) {
			//Log.i("Himi", "ACTION_DOWN");
		//} else if (event.getAction() == MotionEvent.ACTION_MOVE) {
			//Log.i("Himi", "ACTION_MOVE");
		//}
		//synchronized (object) {//备注2
			//try {
				//object.wait(TIME);
			//} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			//}
		//}
		//这里一定要返回true！
		return true;
	}


	public  class CameraSizeComparator implements Comparator<Camera.Size>{  
		@Override
		public int compare(android.hardware.Camera.Size lhs,
				android.hardware.Camera.Size rhs) {
			// TODO Auto-generated method stub
			if(lhs.width == rhs.width){  
                return 0;  
            }  
            else if(lhs.width > rhs.width){  
                return 1;  
            }  
            else{  
                return -1;  
            }  
		}  
  
    } 
	
	private CameraSizeComparator sizeComparator = new CameraSizeComparator();  
	
	private int mZoomIndex = -1;
	
	private int mAnimXOffset = 0;
	private int mAnimYOffset = 0;
	private ViewGroup.LayoutParams mBackupZoomedLP = null;
	
	
	public boolean isZoomIn(){
		return (mZoomIndex >= 0); 
	}
	
	public void zoomIn(final int index){
		final View frame = (View)findViewById(R.id.screen);
		
		mAnimXOffset = (index%3 - 1) * (-1080);
		mAnimYOffset = (index/3 - 1) * (-1920);
		
		frame.animate().scaleX(3.0f).scaleY(3.0f).translationX(mAnimXOffset).
				translationY(mAnimYOffset).withEndAction(new Runnable(){

			@Override
			public void run() {
				frame.setScaleX(1.0f);
				frame.setScaleY(1.0f);
				frame.setTranslationX(0);
				frame.setTranslationY(0);
				
				for (int i=0; i<9; i++){
					View preview = (View)findViewById(R.id.gl_preview1+i);

					if (i != index){
						preview.setVisibility(View.GONE);
						mRenderThread[i].suspendRendering();
					}
					else {
						final GLCameraRenderThread renderer = mRenderThread[i];
						mBackupZoomedLP = preview.getLayoutParams();
						RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(1080, 1920);
						preview.setLayoutParams(params);
						renderer.suspendRendering();
						
						final ViewTreeObserver observer = frame.getViewTreeObserver();
						observer.addOnDrawListener(new OnDrawListener(){

							@Override
							public void onDraw() {
								// TODO Auto-generated method stub
								observer.removeOnDrawListener(this);
								
								frame.post(new Runnable(){

									@Override
									public void run() {
										// TODO Auto-generated method stub
										renderer.resumeRendering();
										onFrameAvailable(null);
										
							    		Camera.Parameters params = mCamera.getParameters();

							    		//params.setPreviewSize(1920, 1080);
							    		List<android.hardware.Camera.Size> previewSizes = params.getSupportedPreviewSizes();  
							    		Camera.Size s = getPropPictureSize(previewSizes,1.0f,640);
							    		params.setPreviewSize(s.width, s.height);
							    		
							    		mCamera.setParameters(params);
									}
									
								});
							}
							
						});
						
					}
				}
				//frame.requestLayout();				
			}
			
		});
		
		mZoomIndex = index;
	}
	
	public void zoomOut(){
		final View frame = (View)findViewById(R.id.screen);
		
		View zoomedPreview = (View)findViewById(R.id.gl_preview1+mZoomIndex);
		zoomedPreview.setLayoutParams(mBackupZoomedLP);
				
		for (int i=0; i<9; i++){
			View preview = (View)findViewById(R.id.gl_preview1+i);
			preview.setVisibility(View.VISIBLE);
		}
		
		mRenderThread[mZoomIndex].suspendRendering();
		frame.requestLayout();
		
		frame.setScaleX(3.0f);
		frame.setScaleY(3.0f);
		frame.setTranslationX(mAnimXOffset);
		frame.setTranslationY(mAnimYOffset);
				
		frame.animate().scaleX(1.0f).scaleY(1.0f).translationX(0).translationY(0).withEndAction(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i=0; i<9; i++){
					mRenderThread[i].resumeRendering();
				}
				onFrameAvailable(null);//Since nobody updated after last frame, we kick it again
				
	    		Camera.Parameters params = mCamera.getParameters();

	    		//params.setPreviewSize(1920, 1080);
	    		List<android.hardware.Camera.Size> previewSizes = params.getSupportedPreviewSizes();  
	    		Camera.Size s = getPropPictureSize(previewSizes,1.0f,3264/*640*/);
	    		params.setPreviewSize(s.width, s.height);
	    		
	    		mCamera.setParameters(params);
			}
			
		});
		
		mZoomIndex = -1;
	}


	static private GLPreviewActivity appInst = null;
	private GLCameraRenderThread mRenderThread[] = new GLCameraRenderThread[/*9*/1];
	private int mActiveRender = 0;
	FrameLayout frame;
	ImageButton shutterBtn;

	static public GLPreviewActivity getAppInstance(){
		return appInst;
	}

	private void initUI(){
		shutterBtn = (ImageButton)findViewById(R.id.btn_shutter);
		frame = (FrameLayout)findViewById(R.id.gl_preview1);
	}

	private class BtnListeners implements OnClickListener
	{
		@Override
		public void onClick(View v) {
			if (v.getId() == R.id.btn_shutter) {
				mRenderThread[0].suspendCameraPreview();
				//mRenderThread[0].suspendRendering();
				//mRenderThread[0].resumeRendering();

				//Toast.makeText(CameraActivity.this, "Progressing ...", Toast.LENGTH_SHORT).show();
				//CameraInterface.getInstance().doTakePicture(CameraActivity.this);
			}
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_glpreview);

		initUI();
		shutterBtn.setOnClickListener(new BtnListeners());

		TextureView mTextureView;
		mTextureView = new FilterTextureView(this, 0);
		mTextureView.setSurfaceTextureListener(new TextureCallback(0, GLCameraRenderThread.FILTER_FISHEYE));
		
		frame.addView(mTextureView);

		mActiveRender = 1;
		appInst = this;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	}


    @Override
    protected void onPause() {
        super.onPause();
        // The following call pauses the rendering thread.
        // If your OpenGL application is memory intensive,
        // you should consider de-allocating objects that
        // consume significant memory here.
        //mGLSurfaceView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // The following call resumes a paused rendering thread.
        // If you de-allocated graphic objects for onPause()
        // this is a good place to re-allocate them.attachToGLContext
        //mGLSurfaceView.onResume();
    }
    
    public boolean equalRate(Camera.Size s, float rate){  
        float r = (float)(s.width)/(float)(s.height);  
        if(Math.abs(r - rate) <= 0.03)  
        {  
            return true;  
        }  
        else{  
            return false;  
        }  
    }  
    
    public Camera.Size getPropPictureSize(List<Camera.Size> list, float th, int minWidth){  
        Collections.sort(list, sizeComparator);  
  
        int i = 0;  
        for(android.hardware.Camera.Size s:list){  
            if((s.width >= minWidth) /*&& equalRate(s, th)*/){
                //Log.i(TAG, "PictureSize : w = " + s.width + "h = " + s.height);  
                break;  
            }  
            i++;  
        }  
        if(i == list.size()){  
            i = 0;
        }  
        return list.get(i);  
    } 
    
    synchronized public void startCamera(int texture){
    	if (null == mSurfaceTexture){
	    	mCamera = getCameraInstance();
	    	
	    	mSurfaceTexture = new SurfaceTexture(texture);

	    	//当新一帧图像对SurfaceTexture可用时调用
	    	mSurfaceTexture.setOnFrameAvailableListener(this);
	    	
	    	try{
	    		Camera.Parameters params = mCamera.getParameters();
	    		
	    		List<android.hardware.Camera.Size> previewSizes = params.getSupportedPreviewSizes();  
	            //for(int i=0; i< previewSizes.size(); i++){  
	            //    android.hardware.Camera.Size size = previewSizes.get(i);  
	            //    //Log.i(TAG, "previewSizes:width = "+size.width+" height = "+size.height);  
	            //} 
	            //android.hardware.Camera.Size size = previewSizes.get(0);
	            //params.setPreviewSize(size.width, size.height);
	    		//params.setPreviewSize(1920, 1080);
				//Camera.Size s = getPropPictureSize(previewSizes,1.0f,1280/*640*/);
                //Camera.Size s = getPropPictureSize(previewSizes,1.0f,4208/*640*/);
                //Camera.Size s = getPropPictureSize(previewSizes,1.0f,2064/*640*/);
	    		Camera.Size s = getPropPictureSize(previewSizes,1.0f,3264/*640*/);
                //Camera.Size s = getPropPictureSize(previewSizes,1.0f,1080/*640*/);
	    		params.setPreviewSize(s.width, s.height);
	    		mCamera.setParameters(params);
	    		mCamera.setDisplayOrientation(0);
	    		mCamera.setPreviewTexture(mSurfaceTexture);
	    		mCamera.startPreview();

	    	}
	    	catch (Exception e){
	    		e.printStackTrace();
	    	}
	    	
	    	mSurfaceTexture.detachFromGLContext();
    	}
    	else {
    		//mSurfaceTexture.attachToGLContext(texture);
    	}
    }

    public void attachCameraTexture(int texture) {
		mSurfaceTexture.attachToGLContext(texture);
    }
    
    public void detachCAmeraTexture() {
    	mSurfaceTexture.detachFromGLContext();
    }
    
	/** A safe way to get an instance of the Camera object. */
	public static Camera getCameraInstance(){
	    Camera c = null;
	    try {
	        c = Camera.open(); // attempt to get a Camera instance
	    }
	    catch (Exception e){
	        // Camera is not available (in use or does not exist)
	    }
	    return c; // returns null if camera is unavailable
	}

	@Override
	public void onFrameAvailable(SurfaceTexture surfaceTexture) {
		// TODO Auto-generated method stub

		for (int i=0; i < mActiveRender; i++){
			synchronized(mRenderThread[i]){
				mRenderThread[i].notify();
			}
		}
	}
	
	public void updateCamPreview(){
		//更新纹理图像为从图像流中提取的最近一帧
		mSurfaceTexture.updateTexImage();
	}
	
	private Camera mCamera;
	private Timer mAFTimer;
	//private GLSurfaceView mGLSurfaceView;
	private SurfaceTexture mSurfaceTexture = null;
}
